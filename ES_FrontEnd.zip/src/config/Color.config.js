export const PrimaryColor="#276bb9"

export const SecondaryColor="hsl(0,0%,90%)"

export const skyBlue="#45a1e0"

export const MoonLight="#f7c972"

export const PaleYellow="#fae3b2"

export const SparkGreen="#7bbf34"

export const PaleGreen="#82c937"