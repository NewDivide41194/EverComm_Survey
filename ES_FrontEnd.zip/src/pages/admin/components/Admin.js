import React from "react";

const Admin = props => {


  return (
    <div className="py-5">
     <h1>Admin Dashboard</h1>
    </div>
  );
};

export default Admin;