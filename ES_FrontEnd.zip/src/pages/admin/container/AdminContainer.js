import React from 'react'
import Admin from '../components/Admin'

const AdminContainer=()=>{
    return(
    <div>
        <Admin/>
    
    </div>
    )
}

export default AdminContainer 