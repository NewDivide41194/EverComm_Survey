import React from "react";
import FinalPage from "../component/FinalPage";

const FinalPageContainer = () => {
  
  return <FinalPage/>;
};

export default FinalPageContainer;
